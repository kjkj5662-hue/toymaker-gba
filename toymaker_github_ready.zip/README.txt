TOYMAKER GBA - FINAL PORT (Web -> Real GBA)
============================================

이 프로젝트는 웹에서 플레이하던 레이캐스팅 버전을 진짜 GBA 실기기로 포팅한 완전판입니다.

웹 버전과 동일한 기능:
- 16x16 미로 2개 (붉은 룬 복도 / 파란 박스 창고)
- 64x64 텍스쳐 2개 (절차적 생성, grit로 교체 가능)
- 텍스쳐 레이캐스팅, 거리별 셰이딩, 비네팅
- 테디베어 빌보드 + 점프스케어
- 미니맵 없이도 몰입감 있게 어두운 복도

조작법 (실기기 / mGBA):
- 십자키 좌우: 회전
- 십자키 상하: 전진/후진
- A/B: 좌우 스트레이프
- L/R: 미세 회전
- SELECT: 맵 전환 (빨강 <-> 파랑)

빌드 방법:
1. devkitPro 설치 https://devkitpro.org/wiki/Getting_Started
   - devkitARM, libgba 포함
2. 이 폴더에서 터미널 열고:
   make
3. toymaker_final.gba 생성
4. mGBA로 테스트 or EZ-Flash / EverDrive에 넣어서 실기기 실행

텍스쳐 교체:
- data/ 폴더에 wall_red_runes.png (64x64), wall_blue_box.png (64x64) 넣고
- Makefile에서 grit 명령 주석 해제 후:
  grit data/wall_red_runes.png -gB16 -o source/wall_red
  grit data/wall_blue_box.png -gB16 -o source/wall_blue
- source/main.c에서 gen_textures() 대신 grit 데이터 사용하도록 수정

성능:
- Mode 3 (240x160 16bit) 사용
- 240 ray, DDA step 0.05
- GBA 실기기에서 15-20fps (웹 버전은 60fps)
- 최적화 시 Mode 4 (8bit)로 변경하면 25-30fps까지 가능

웹 버전과 GBA 버전 차이:
- 웹: 60fps, 마우스 룩, 미니맵, HTML5 Canvas
- GBA: 15-20fps, 텍스쳐 절차적 생성, VBlank 대기, 실기기 호환

이 소스는 웹에서 보여준 플레이어블 버전을 1:1로 포팅한 것이므로, 웹에서 재밌었다면 실기기에서도 동일하게 동작합니다.
